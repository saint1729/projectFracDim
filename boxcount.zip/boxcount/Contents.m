% Box Counting
% Version 1.10 09-July-2008
% F. Moisy, moisy_@_fast.u-psud.fr
%
%   boxcount          - 1D, 2D and 3D box-counting
%   randcantor        - 1D, 2D and 3D generalized random Cantor set
%   demo              - Demo file (publish it to produce an html help page)

